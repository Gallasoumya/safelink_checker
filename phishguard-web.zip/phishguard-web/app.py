from flask import Flask, jsonify, request, send_from_directory
from analyzer import analyze

app = Flask(__name__, static_folder="static")


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.post("/api/analyze")
def api_analyze():
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    if not url:
        return jsonify(error="Missing 'url'"), 400
    if len(url) > 2000:
        return jsonify(error="URL too long"), 400
    return jsonify(analyze(url))


if __name__ == "__main__":
    app.run(debug=True)
