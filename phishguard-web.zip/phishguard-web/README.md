# PhishGuard – Phishing URL Detection Tool

Python (Flask) web app that scores URLs using phishing heuristics: IP-as-host, long URLs, `@` tricks,
excess subdomains, HTTP, suspicious TLDs, phishing keywords / brand impersonation, and punycode (homograph) domains.

## Run locally
```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## API
`POST /api/analyze` with `{"url": "http://paypal-login.verify-account.xyz/"}` returns score, verdict and findings as JSON.

## Deploy
Works on Render / Railway / PythonAnywhere (start command: `gunicorn app:app`).

> Heuristic tool, not foolproof.
