"""Core phishing-URL heuristics (no UI dependencies)."""
import re
import ipaddress
from datetime import datetime
from urllib.parse import urlparse


# ----------------------------- Config -----------------------------
SUSPICIOUS_TLDS = {'.zip', '.mov', '.review', '.tk', '.xyz', '.info', '.top', '.club', '.online'}
SUSPICIOUS_KEYWORDS = {'login', 'signin', 'verify', 'account', 'update', 'secure', 'password',
                       'banking', 'confirm', 'authenticate', 'admin'}
BRAND_KEYWORDS = {'paypal', 'ebay', 'amazon', 'google', 'apple', 'microsoft', 'facebook', 'instagram',
                  'twitter', 'netflix', 'bank', 'chase', 'wellsfargo', 'linkedin', 'zoom', 'teams', 'vpn'}
MAX_URL_LENGTH = 90
MAX_SUBDOMAINS = 4

COLORS = {
    "safe": "#22c55e", "low": "#eab308", "medium": "#f97316",
    "high": "#ef4444", "error": "#a855f7", "info": "#3b82f6",
}


# ----------------------------- Checks -----------------------------
def is_ip(host):
    try:
        ipaddress.ip_address(host)
        return True
    except (ValueError, TypeError):
        return False


def check_ip_address(host):
    if host and is_ip(host):
        return True, 15, f"Uses an IP address ({host}) instead of a domain name."
    return False, 0, ""


def check_url_length(url):
    if len(url) > MAX_URL_LENGTH:
        return True, 5, f"URL is unusually long ({len(url)} chars, limit {MAX_URL_LENGTH})."
    return False, 0, ""


def check_at_symbol(url):
    part = url.split('://', 1)[1] if '://' in url else url
    authority = re.split(r'[/?#]', part, 1)[0]
    if '@' in authority:
        return True, 20, "Contains '@' in the authority part - can hide the real destination."
    return False, 0, ""


def check_subdomain_count(host):
    if not host or is_ip(host):
        return False, 0, ""
    parts = host.split('.')
    if len(parts) > 2 and len(parts[-1]) <= 3 and len(parts[-2]) <= 3:
        sub = parts[:-2]
    elif len(parts) > 1:
        sub = parts[:-1]
    else:
        sub = parts
    if len(sub) > MAX_SUBDOMAINS:
        return True, 10, f"Has {len(sub)} subdomains (limit {MAX_SUBDOMAINS}) - may hide the real domain."
    return False, 0, ""


def check_https(scheme):
    if scheme and scheme.lower() == 'https':
        return False, 0, ""
    if scheme and scheme.lower() == 'http':
        return True, 5, "Uses HTTP instead of HTTPS."
    return True, 10, f"Insecure or missing scheme ('{scheme or 'None'}')."


def check_suspicious_tld(host):
    if not host or is_ip(host):
        return False, 0, ""
    parts = host.split('.')
    if len(parts) > 1:
        tld = "." + parts[-1].lower()
        if tld in SUSPICIOUS_TLDS:
            return True, 8, f"TLD '{tld}' is commonly abused for phishing/spam."
    return False, 0, ""


def check_keywords(url_lower, host):
    kws, brands, score = set(), set(), 0
    # registered domain label (e.g. paypal in www.paypal.com) = likely the real brand
    labels = (host or "").split('.')
    registered = labels[-2] if len(labels) >= 2 else ""
    for k in SUSPICIOUS_KEYWORDS:
        if re.search(r'\b' + re.escape(k) + r'\b', url_lower):
            kws.add(k)
            score += 3
    for b in BRAND_KEYWORDS:
        if re.search(r'\b' + re.escape(b) + r'\b', url_lower) and registered != b:
            brands.add(b)
            score += 5
    if kws and brands:
        return True, score + 5, f"Suspicious keywords {sorted(kws)} combined with brand names {sorted(brands)}."
    if kws:
        return True, score, f"Suspicious keywords found: {sorted(kws)}."
    if brands:
        return True, score + 5, f"Possible brand impersonation: {sorted(brands)}."
    return False, 0, ""


def check_punycode(host):
    if not host:
        return False, 0, ""
    try:
        if 'xn--' in host.lower():
            return True, 15, f"Punycode domain ('{host}') - possible homograph attack."
        enc = host.encode('idna').decode('ascii')
        if enc != host and 'xn--' in enc:
            return True, 15, f"Non-ASCII characters in domain ('{enc}') - possible homograph attack."
    except (UnicodeError, TypeError, AttributeError):
        pass
    return False, 0, ""


def severity(score):
    return "high" if score >= 15 else "medium" if score >= 8 else "low"


def analyze(url):
    """Returns a dict with parsed parts, findings, score and verdict."""
    result = {"url": url, "scheme": None, "host": None, "path": "", "notes": [],
              "findings": [], "score": 0, "level": "safe", "verdict": ""}
    try:
        temp = url
        if not re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*://', temp):
            temp = "http://" + temp
            result["notes"].append(f"No scheme found - assumed http:// ({temp})")
        p = urlparse(temp)
        host = p.hostname
        if not host:
            raise ValueError("Could not read a domain/IP from the URL.")
        result.update(scheme=p.scheme, host=host, path=p.path or "/")

        checks = [
            check_ip_address(host), check_url_length(temp), check_at_symbol(temp),
            check_subdomain_count(host), check_https(p.scheme), check_suspicious_tld(host),
            check_keywords(temp.lower(), host), check_punycode(host),
        ]
        for flagged, score, msg in checks:
            if flagged:
                result["findings"].append({"msg": msg, "score": score, "level": severity(score)})
                result["score"] += score

        s = result["score"]
        if s == 0:
            result["level"], result["verdict"] = "safe", "Likely Safe"
        elif s < 15:
            result["level"], result["verdict"] = "low", "Low Suspicion"
        elif s < 30:
            result["level"], result["verdict"] = "medium", "Medium Suspicion"
        else:
            result["level"], result["verdict"] = "high", "High Suspicion - Potentially Phishing"
    except Exception as e:
        result["level"], result["verdict"] = "error", "Error"
        result["notes"].append(f"Could not analyze: {e}")
    return result


def to_text_report(r):
    lines = [f"URL: {r['url']}", f"Verdict: {r['verdict']}", f"Score: {r['score']}",
             f"Scheme: {r['scheme']}  Host: {r['host']}  Path: {r['path']}", ""]
    lines += [f"[!] {f['msg']} (+{f['score']})" for f in r["findings"]] or ["No indicators found."]
    lines += [""] + [f"[Note] {n}" for n in r["notes"]]
    lines += ["", "Disclaimer: heuristic tool, not foolproof."]
    return "\n".join(lines)
